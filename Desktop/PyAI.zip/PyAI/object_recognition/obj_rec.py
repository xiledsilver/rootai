'''

	Object Recognition

'''

import cv2, time, os
import cv2.cv 
import numpy as np
from matplotlib import pyplot as plt

video_capture = cv2.VideoCapture(0)
ret, img = video_capture.read()
cimg = img
edges = cv2.Canny(img,5,100)
lines = cv2.HoughLines(edges,1,np.pi/1,170)
for rho,theta in lines[0]:
    a = np.cos(theta)
    b = np.sin(theta)
    x0 = a*rho
    y0 = b*rho
    x1 = int(x0 + 1000*(-b))
    y1 = int(y0 + 1000*(a))
    x2 = int(x0 - 1000*(-b))
    y2 = int(y0 - 1000*(a))

    cv2.line(img,(x1,y1),(x2,y2),(0,0,255),2)
    
circles = cv2.HoughCircles(img,cv2.cv.HOUGH_GRADIENT,1,20, param1=50,param2=30,minRadius=0,maxRadius=0)

circles = np.uint16(np.around(circles))
for i in circles[0,:]:
    # draw the outer circle
    cv2.circle(cimg,(i[0],i[1]),i[2],(0,255,0),2)
    # draw the center of the circle
    cv2.circle(cimg,(i[0],i[1]),2,(0,0,255),3)

cv2.imshow('baerock',img)
cv2.waitKey(10000)


	
