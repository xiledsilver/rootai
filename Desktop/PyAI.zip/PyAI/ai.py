'''

	Python Artificial Intelligence / Personal Assistant. Copyright Tyler Silverwood (\), 2015.
	    [PyAI]
	------------------------------------------------------------------
	
	
'''

import aiwp, aicalculate as calc, aiconfig, aiutil, subprocess, os, time, face_detect

userInput = subprocess.Popen(args=[
		"gnome-terminal", "--command=python getUserTextInput.py"])

face_detect.checkFace('root.jpg')
