'''

	Calculation module for PyAI
	Used to determine if the command given by the user matches the module given from Main.
	
'''

def __CALC__(command, moduleCheck):
	breakLoop = False
	trueMod = 0
	clen = len(command)
	command += "                          "        # Ensures no errors come about from command being too short.
	for char in range(clen+1):
		if command[char] == moduleCheck[0]:
			if command[char + len(moduleCheck)] == " " or command[char + len(moduleCheck)] == "." or command[char + len(moduleCheck)] == "?" or command[char + len(moduleCheck)] == "!":   # If the char in the command equals the first letter of the requested module, it
				for charMod in range(len(moduleCheck)):										  # checks the rest of the word in the command. Prevents it from catching things like 'hi' in the word 'this'
					if command[char+charMod] == moduleCheck[charMod]:              # Loops through each character of the command, until a set of characters equals the
						trueMod += 1                                               # requested module.
						if trueMod == len(moduleCheck):
							return True
							breakLoop = True
							break
					else:
						trueMod = 0            # Prevents it from gathering a word out of split up characters, such as W E A T H E R, or chars in different words. 
				if breakLoop == True:          # Stops checking the command if it caught the requested module within the command. 
					break
			
def __listCalc__(wordList,wordCheck):
	wllen = len(wordList)
	for char in range(wllen):
		if wordList[char] == wordCheck:
			return True
			

