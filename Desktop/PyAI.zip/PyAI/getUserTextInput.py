# Gets user text input.

import aiconfig, os
aiDir = aiconfig.getDir()

while True:
	uinput = raw_input('<>user@PyAI\\\\ ')
	if uinput == '':
		uinput = '<>'
	os.system('echo "' + uinput + '" > ' + aiDir + '/userInput.txt')
	print ''

