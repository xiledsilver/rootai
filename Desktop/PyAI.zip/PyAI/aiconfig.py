'''
	PyAI Configuration File
'''

def getDir():
	directory = '/home/rt/Desktop/PyAI'                                                  # Enter the directory containing the PyAI Files here.
	return directory

def getName():
	usersName = 'Silver'                                                  # Enter your nickname here.
	return usersName
	
def getSecure():
	secure = True                                                   # If you wish to enter your user password every time a sudo command is called, leave on True.
	return secure                                                   # If you want it to automatically input your user password, set it to False and enter password below.
	
def getPassword():
	password = 'l9k8j7h6g5f4d3s2a1'                                                   # If secure = False, enter your user password here.
	return password
	
def getWikip():
	useWikip = False                                                 # If you want the search module to use wikipedia, set to True. Defaults on False.
	return useWikip

def getWolfram():
	useWolfram = False                                               # If you want the search module to use Wolfram Alpha, set to True. Defaults on False.
	return useWoflram
	
def useMultiTerminal():
	useTerm = False
	return useTerm
