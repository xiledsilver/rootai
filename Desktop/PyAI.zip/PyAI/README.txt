####     PyAI Program      ####

PyAI Program, Copyright Tyler Silverwood.

You may modify and share the code, but all rights to the code belong soley to the owner. You may not sell the program without express permission from the owner, nor advertise the program, even heavily modified, as your own without express permission from the owner. Users accept the responsibility of program's effects upon their and others machines. The Owner is not responsible for any damage caused by correct use, misuse, or modified use of the program.

All custom modules included within the main package of this program are owned by the Owner. Owner does not claim responsibility or ownership of any imported modules not included within the main package.
------------------------------------

current build: {indev}0.25
stable? (n)

------------------------------------

Designed for use on Linux machines.

Many functions of this program are reliant on the machine being connected to the internet. Program may cease to function or behaive strangely if the machine is not connected.

------------------------------------

How to install:
---------------
1) Open up the 'aiconfig.py' file within the ui folder.
2) Modify settings, and save.
3) Open terminal.
4) cd to the directory containing the files.
5) Run 'python installDependencies.py'
[Installs modules, or applications required by the program to function properly]


How to run:
-----------
1) Open terminal.
2) cd to the directory containing the files.
3) Run 'python PyAI.py'
