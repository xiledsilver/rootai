import aiutil
import os
import aicalculate as calc            # Standalone word processing that returns the list of words, and their types.
import aiconfig                                                                  # words / wordList
import time
	

def wp(sen):
	aiutil.saveInputLog(sen)
	names = aiutil.loadNameFile()
	numbers = aiutil.loadNumFile()
	operators = aiutil.loadOperatorsFile()
	sen = sen.lower()
	senLen = len(sen)
	phrases = ['']
	words = ['']
	wordType = []
	phraseCount = 0
	wordCount = 0
	global equalsPos 
	equalsPos = 0
	global questionPos 
	questionPos = 0
	equalPosAssigned = False
	questionPosAssigned = False
	mathSentence = ''
	sen += ' '
	global sentenceType
	sentenceType = ''
	newWord = False
	for char in range(senLen):          #Adds each phrase in a command to the phrases list.
		if sen[char] != '.' and sen[char] != ',' and sen[char] != '?' and sen[char] != '!':
			if newWord == True and sen[char] != ' ':
				phrases.append(sen[char])
				newWord = False
				phraseCount += 1
			elif sen[char] + sen[char+1] == '  ':
				break
			else:
				phrases[phraseCount] += sen[char]
		else:
			newWord = True
			
	newWord = False
	for char in range(senLen):     
		if sen[char] != ' ' and sen[char] != '.' and sen[char] != ',' and sen[char] != '?' and sen[char] != '!' and sen[char] + sen[char+1] != '  ':
			if newWord == True:
				words.append(sen[char])
				newWord = False
				wordCount += 1
			else:
				words[wordCount] += sen[char]
		else:
			newWord = True
	
	for wordsLoop in range(wordCount+1):
		doneLoop = 0
		for namesLoop in range(len(names)):
			if words[wordsLoop] == names[namesLoop]:
				wordType.append('name')                             # Finds names within the sentence/wordlist, and sets all others to the neutral <>
				break
			elif doneLoop == len(names)-1:
				wordType.append('<>')
				break
			else:
				doneLoop += 1
	
	for wordsLoop in range(wordCount + 1):
		for numLoop in range(len(numbers)):
			for num2Loop in range(len(words[wordsLoop])):
				if words[wordsLoop][num2Loop] == numbers[numLoop] and wordType[wordsLoop] == '<>':
					wordType[wordsLoop] = 'num'
				elif words[wordsLoop][num2Loop] == numbers[numLoop] + '%' and wordType[wordsLoop] == '<>':
					wordType[wordsLoop] = 'num.percent'
			
	for wordsLoop in range(wordCount + 1):
		for operatorLoop in range(len(operators)):
			if words[wordsLoop] == operators[operatorLoop] and wordType[wordsLoop] == '<>':
				wordType[wordsLoop] = operators[operatorLoop]
				if wordType[wordsLoop] == 'takes' or wordType[wordsLoop] == 'gives' or wordType[wordsLoop] == 'loses' or wordType[wordsLoop] == 'minus' or wordType[wordsLoop] == 'less':
					wordType[wordsLoop] = '-'
				elif wordType[wordsLoop] == 'gets' or wordType[wordsLoop] == 'gains' or wordType[wordsLoop] == 'recieves' or wordType[wordsLoop] == 'plus' or wordType[wordsLoop] == 'more':
					wordType[wordsLoop] = '+'
				elif wordType[wordsLoop] == 'divide' or wordType[wordsLoop] == 'divided' or wordType[wordsLoop] == 'divided by':
					wordType[wordsLoop] = '/'
				elif wordType[wordsLoop] == 'multiply' or wordType[wordsLoop] == 'times':
					wordType[wordsLoop] = '*'
	
	for wordsLoop in range(wordCount + 1):
		if words[wordsLoop] == 'you' or words[wordsLoop] == 'pyai' or words[wordsLoop] == 'root' and wordType[wordsLoop] == '<>':
			wordType[wordsLoop] = 'self'
	
	for wordsLoop in range(wordCount + 1):
		if words[wordsLoop] == 'are' or words[wordsLoop] == 'is' or words[wordsLoop] == 'was' or words[wordsLoop] == 'am' and wordType[wordsLoop] == '<>':
			wordType[wordsLoop] = '='
			if not equalPosAssigned:
				equalsPos = wordsLoop
				equalPosAssigned = True
			
	for wordsLoop in range(wordCount + 1):
		if words[wordsLoop] == 'dumb' or words[wordsLoop] == 'stupid' or words[wordsLoop] == 'retarded' or words[wordsLoop] == 'bad' or words[wordsLoop] == 'evil' and wordType[wordsLoop] == '<>':
			wordType[wordsLoop] = 'derogatory' 
			
	for wordsLoop in range(wordCount + 1):
		if words[wordsLoop] == 'smart' or words[wordsLoop] == 'intelligent' or words[wordsLoop] == 'genius' or words[wordsLoop] == 'wise' and wordType[wordsLoop] == '<>':
			wordType[wordsLoop] = 'compliment'
	
	for wordsLoop in range(wordCount + 1):
		if words[wordsLoop] == 'me' or words[wordsLoop] == 'i' and wordType[wordsLoop] == '<>':
			wordType[wordsLoop] = 'user'
	
	for wordsLoop in range(wordCount + 1):
		if words[wordsLoop] == 'says' or words[wordsLoop] == 'said' or words[wordsLoop] == 'say' and wordType[wordsLoop] == '<>':
			wordType[wordsLoop] = 'speech'
			
	for wordsLoop in range(wordCount + 1):
		if words[wordsLoop] == 'how' or words[wordsLoop] == 'what' or words[wordsLoop] == 'who' or words[wordsLoop] == 'where' or words[wordsLoop] == 'when' or words[wordsLoop] == 'why' or words[wordsLoop] == 'can' or words[wordsLoop] == 'if' and wordType[wordsLoop] == "<>":
			wordType[wordsLoop] = 'question'
			if not questionPosAssigned:
				questionPos = wordsLoop
				questionPosAssigned = True
			
	for wordsLoop in range(wordCount + 1):
		if words[wordsLoop] == 'date' or words[wordsLoop] == 'time':
			wordType[wordsLoop] = 'time'
			
	for wordsLoop in range(wordCount + 1):
		if words[wordsLoop] == 'open' or words[wordsLoop] == 'start' or words[wordsLoop] == 'launch':
			wordType[wordsLoop] = 'open'
	
	for wordsLoop in range(wordCount+1):
		if words[wordsLoop] == '?' or calc.__listCalc__(wordType,'question'):             # Keep sentence types below all wordType processing.
			sentenceType = 'question'
			break
		elif calc.__listCalc__(wordType,'num') and calc.__CALC__(sen,'timer') and calc.__CALC__(sen,'set') and calc.__CALC__(sen,'for'):
			sentenceType = 'timer'
			break
		elif wordType[wordsLoop] == 'open':
			sentenceType = 'open'
			break
		
	if wordCount == 0:
		return wordType[0]
	else:
		return wordType
	

