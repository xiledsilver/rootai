import cv2
import sys

cascPath = '/home/rt/Desktop/PyAI/facial_recognition/haarcascade_frontalface_default.xml'
faceCascade = cv2.CascadeClassifier(cascPath)

video_capture = cv2.VideoCapture(0)

peopleAmnt = int(open('/home/rt/Desktop/PyAI/facial_recognition/peopleAmnt.txt').read())

while True:
    # Capture frame-by-frame
    ret, frame = video_capture.read()

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    faces = faceCascade.detectMultiScale(
        gray,
        scaleFactor=1.3,
        minNeighbors=5,
        minSize=(30, 30),
        flags=cv2.cv.CV_HAAR_SCALE_IMAGE
    )

    # Draw a rectangle around the faces
    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
    if len(faces) != 0:
		for no in range(peopleAmnt+1):
			if len(str(peopleAmnt)) == 1:
				cv2.imwrite('/home/rt/Desktop/PyAI/facial_recognition/pictures/subject0' + str(no) + '.t.png', frame)
			else:
				cv2.imwrite('/home/rt/Desktop/PyAI/facial_recognition/pictures/subject' + str(no) + '.t.png', frame)
		break
        

# When everything is done, release the capture
video_capture.release()
cv2.destroyAllWindows()
