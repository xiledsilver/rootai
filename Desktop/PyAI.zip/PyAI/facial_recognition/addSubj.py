import cv2
import sys
import time

cascPath = '/home/rt/Desktop/PyAI/facial_recognition/haarcascade_frontalface_default.xml'
faceCascade = cv2.CascadeClassifier(cascPath)

video_capture = cv2.VideoCapture(-1)
no = 0

peopleAmnt = int(open('/home/rt/Desktop/PyAI/facial_recognition/peopleAmnt.txt').read())

while True:
    # Capture frame-by-frame
    ret, frame = video_capture.read()

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    faces = faceCascade.detectMultiScale(
        gray,
        scaleFactor=1.25,
        minNeighbors=5,
        minSize=(30, 30),
        flags=cv2.cv.CV_HAAR_SCALE_IMAGE
    )

    # Draw a rectangle around the faces
    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
    if len(faces) != 0:
		cv2.imshow('Img',frame)
		print 'Press "y" to add img to files'
		if cv2.waitKey(0) == 1048697:
			cv2.imwrite('/home/rt/Desktop/PyAI/facial_recognition/pictures/subject09.' + str(no+1) + '.png', frame)
			no += 1
			print 'Images collected: ' + str(no) + '/4'
			print ''
			if no != 4:
				time.sleep(1)
				print 'Enter a new position...'
				time.sleep(2)
				ret, frame = video_capture.read()
		else:
			print 'NOPE'
		if no == 4:
			break
        

# When everything is done, release the capture
video_capture.release()
cv2.destroyAllWindows()
