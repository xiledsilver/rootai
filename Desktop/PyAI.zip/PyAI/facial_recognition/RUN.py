'''

	Facial Recognition.
	Gets input from webcam, then compares it to known people and returns the number of who it is similar to.
	
	Lib:
		0 - Tyler Silverwood


'''

import os, subprocess, time

lib = ['Tyler Silverwood']

PIPE_PATH = "/tmp/facePipe"
PIPE_PATH_2 = "/tmp/aipipe2"

if not os.path.exists(PIPE_PATH):
    os.mkfifo(PIPE_PATH)
if not os.path.exists(PIPE_PATH_2):
	os.mkfifo(PIPE_PATH_2)

subprocess.Popen(['xterm', '-T',' // FACIAL RECOGNITION','-e', 'tail', '-f', PIPE_PATH])

p = open(PIPE_PATH,'w')
       

p.write('GETTING IMAGE\n')
time.sleep(1)
os.system('python faces_2.py')
time.sleep(1)
p.write('DETERMINING FACE\n')
os.system('python face_recognizer.py')
matchFile = open('/home/rt/Desktop/PyAI/facial_recognition/isMatch.txt').read().splitlines()
if matchFile[1] != '<>':
	p.write('PERSON: ' + lib[int(matchFile[1])-1] + '\n')
	p.write('CONFIDENCE: ' + matchFile[2])
	p.close()
else:
	p.write('NO MATCH FOUND.')
	time.sleep(5)
	p.close()
	exit()
p2 = subprocess.Popen(['xterm', '-T',' // PyAI','-e', 'tail', '-f', PIPE_PATH_2])
time.sleep(1)
p2.write('WELCOME, ' + lib[int(matchFile[1])-1] + '\n')
