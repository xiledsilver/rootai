'''

	Utility Functions for PyAI
	
'''
import sys
import os
import time
import aiconfig
import subprocess

aiDirectory = aiconfig.getDir()
    
def getInstancesAmnt():
	instanceAmnt = open(aiDirectory + '/miscdata/instanceCount.txt').read()
	return int(instanceAmnt)
	
def updateInstancesAmnt1():
	instanceAmnt = getInstancesAmnt() + 1
	os.system('echo ' + str(instanceAmnt) + ' > ' + aiDirectory + '/miscdata/instanceCount.txt')

def loadNameFile():
	names = open(aiDirectory + "/logicdata/names.txt").read().splitlines()
	return names
	
def loadNumFile():
	numbers = open(aiDirectory + "/logicdata/numbers.txt").read().splitlines()
	return numbers
	
def loadOperatorsFile():
	operators = open(aiDirectory + "/logicdata/operators.txt").read().splitlines()
	return operators
	
def getDate():
	dateFromFile = open(aiDirectory + '/miscdata/date.txt').read()
	return dateFromFile
	
def getFileNo():
	fileNo = ''
	fileNoR = open(aiDirectory + '/miscdata/inputlogs/fileNo.txt').read()
	for char in range(len(fileNoR)-1):
		fileNo += fileNoR[char]
	return int(fileNo)

def saveInputLog(message):
	fileNo = str(getFileNo())
	os.system('echo ' + message + ' > ' + aiDirectory + '/miscdata/inputlogs/inputNo' + fileNo)
	
def appendInputLog(result):
	fileNo = str(getFileNo())
	logFile = open(aiDirectory + '/miscdata/inputlogs/inputNo' + fileNo,'a')
	logFile.write(str(result)+"\n")
	logFile.close()
	
def updateFileNo():
	fileNo = open(aiDirectory + '/miscdata/inputlogs/fileNo.txt').read()
	fileNo = str(int(fileNo) + 1)
	os.system('echo ' + fileNo + ' > ' + aiDirectory + '/miscdata/inputlogs/fileNo.txt')
	
def wipeLogs():
	fileNo = open(aiDirectory + '/miscdata/inputlogs/fileNo.txt').read()
	for wipeNo in range(fileNo):
		os.system('echo - > ' + aiDirectory + '/miscdata/inputlogs/inputNo' + wipeNo)
	os.system('echo 0 > ' + aiDirectory + '/miscdata/inputlogs/fileNo.txt')
	
def getMemAmnt():
	memAmnt = ''
	memAmntF = open(aiDirectory + '/miscdata/knowledge/memAmnt').read()
	for char in range(len(memAmntF)-1):
		memAmnt += memAmntF[char]
	return int(memAmnt)

def storeMem(command,info):
	memAmnt = getMemAmnt()
	info = info.encode('ascii','ignore')
	os.system('echo ' + str(command) + ' > ' + aiDirectory + '/miscdata/knowledge/mem' + str(memAmnt))
	memFile = open(aiDirectory + '/miscdata/knowledge/mem' + str(memAmnt),'a')
	memFile.write(info)
	memFile.write(' ')
	memFile.close()
	os.system('echo ' + str(int(memAmnt) + 1) + ' > ' + aiDirectory + '/miscdata/knowledge/memAmnt')
	
def settimeout(val):
	timeoutFile = open(aiDirectory + '/miscdata/timeout.txt','w')
	timeoutFile.write(val)
	timeoutFile.close()

def listify(sen):
	newWord = True
	sen += '   '
	wordCount = 0
	words = ['']
	for char in range(len(sen)):     
		if sen[char] != ' ' and sen[char] != '.' and sen[char] != ',' and sen[char] != '?' and sen[char] != '!' and sen[char] + sen[char+1] != '  ':
			if newWord == True:
				words.append(sen[char])
				newWord = False
				wordCount += 1
			else:
				words[wordCount] += sen[char]
		else:
			newWord = True
	return words

