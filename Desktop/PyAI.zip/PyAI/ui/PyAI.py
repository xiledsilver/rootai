'''
	Python Artificial Intelligence / Personal Assistant. Copyright Tyler Silverwood (\), 2015.
	    [PyAI]
	------------------------------------------------------------------
	
	How to call custom module functions:
		aiweather
			aiweather.getWeatherData(areaCode)
		printline
			pl.printline(amount)
		calculate
			aicalculate.__CALC__(command, module)
		aiconfig
			aiconfig.getDir()
			aiconfig.getName()
			aiconfig.getSecure()
			aiconfig.getPassword()
			aiconfig.getWikip()
			aiconfig.getWolfram()
		googlemod
			google(phrase)
		aisearch
			searchOnline(command,phrase)            # Phrase should be the key words that __CALC__ looks for, like 'what is'.
		aiutil
			loadNameFile()
			loadOperatorsFile()
			loadNumFile()
			listify(sen)           # Breaks a sentence up into its constituents.
			getDate()              # Loads date from file.
			saveInputLog(command)
			getFileNo()
		ailogic
			logic(sen)             # Takes a list of words (sentence), and attempts to understand it.
		aiwp
			wp(sentence)                             # No-feedback processing for a sentence. Splits it up into list of words and wordtypes. 
		aitimer
			timer(time)
		aiui
			uiSpeak(message)
			
		
			
	
	DEPENDENCIES - Run 'install.py' after editing 'aiconfig.py' to install dependencies:
		Root PyAI Modules  
		pygame           'apt-get install python-pygame'
		pip              'apt-get install python-pip'
		firefox          'apt-get install firefox'
		cmatrix          'apt-get install cmatrix'                                       
		pyttsx           'apt-get install python-pip'     'pip install pyttsx'
		weather-util     'apt-get install weather-util'
		galculator       'apt-get install galculator'
		wikipedia        'apt-get install python-pip'     'pip install wikipedia'
		bc               'apt-get install bc'
	
'''

import aiconfig
import os
aiDirectory = aiconfig.getDir()
os.system('echo 1 > ' + aiDirectory + '/miscdata/instanceCount.txt')
import time 
import aiweather
import aisearch 
import aiwp 
import ailogic
import aitimer
import subprocess
import printline as pl
import aicalculate as calc
import aimemories
import aiui
import aiutil


# ------------------- Imports and Global Variables go above. Functions go below. ------------------- #

PIPE_PATH = '/tmp/mainPipe'
if not os.path.exists(PIPE_PATH):
    os.mkfifo(PIPE_PATH)

def __MAIN__(firstRun):
	if firstRun:
		aimemories.loadMemories('Loading database information...')
		os.system('clear')
		aiui.uiSpeak('Hello, ' + aiconfig.getName())
		time.sleep(2)
		#screensaver = subprocess.Popen(args=[
		#"gnome-terminal", "--command=python aiknowledgescreensaver.py"])
	#else:  
	#	aimemories.loadMemories('Updating database information...')
	os.system('clear')
	aiui.uiSpeak('What are your commands?')
	pl.printline(5)
	time.sleep(.1)
	aiutil.settimeout('0')
	aiutil.updateInstancesAmnt1()
	command = raw_input("<>" + aiconfig.getName() + "@pyAI\\\\ ").lower()
	subprocess.Popen(['xterm','-T','\\\\ LOGIC MODULE', '-e','python', 'ailogic.py', 'True', command ])
	aiutil.settimeout('0')
	__MAIN__(False)

subprocess.Popen(["python","aiDateTime.py"])      # Runs aiDateTime.py in the background, allowing for the current time to be called from the /miscdata/date.txt file.
aiui.setup_ui(True,'Hello, ' + aiconfig.getName())
aiutil.settimeout('0')
subprocess.Popen(['xterm', '-T','\\\\ FACIAL RECOGNITION {Getting Image}', '-e','python','RUN_FACE.py'])
__MAIN__(True)                          #     !!!!!  Leave main at the bottom of all the code. !!!!!     #















 
