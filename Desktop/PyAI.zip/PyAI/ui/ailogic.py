'''

Logic Engine for PyAI, the 'brains' of the AI. Processes a sentence's words, and determine the sentence's approximate meaning and does something with that.       
---------------------

'''

import aicalculate as calc       # aicalculate.__CALC__ checks a sentence for a phrase or word. __listCalc__ checks a list of strings for a word.
import time 
import aiweather
import os,sys
import aiconfig
import aisearch 
import aiutil
import aiwp 
import ailogic
import aitimer
import subprocess
import printline as pl
import aimemories

aiDirectory = aiconfig.getDir()
useSen = ''


def logic(sen):
	aiutil.settimeout('-0-')
	action = ''
	actionLog = ''
	searchSen = ''
	os.system('clear')
	words = aiutil.listify(sen)
	wordType = aiwp.wp(sen)
	wordslen = len(words)
	senType = aiwp.sentenceType
	aiutil.appendInputLog(wordType)
	time.sleep(.15)
	if senType == 'question':
		if calc.__listCalc__(wordType,'question'):
			if calc.__listCalc__(wordType,'='):
				if calc.__listCalc__(wordType,'time') and calc.__CALC__(sen,'the date') or calc.__CALC__(sen,'the time'):
					dateFromFile = open(aiDirectory + '/miscdata/date.txt').read()
					dateMinusOne = ''
					for charDate in range(len(dateFromFile)-1):
						dateMinusOne += dateFromFile[charDate]
					aiui.uiSpeak(dateMinusOne)
					pl.printline(5)
					exitOnReturn = raw_input('Press return to exit.')
					actionLog = 'date'
			
				elif calc.__CALC__(sen,'the weather'):
					aiweather.weatherMain(sen)
					actionLog = 'weather'
				else:
					words.append(' ')
					for wordC in range(wordslen):
						if wordC != aiwp.questionPos and wordC != aiwp.equalsPos:
							searchSen += words[wordC+1]
							searchSen += ' '
					aimemories.checkMemories(searchSen)
					if not aimemories.hasInfo:
						aisearch.searchOnline(searchSen,True)
						actionLog = 'onlineSearch'
					else:
						os.system('clear')
						pl.printline(2)
						print searchSen + " , is: "
						print aimemories.checkMemories(searchSen)
						pl.printline(3)
						exitOnReturn = raw_input("Press return to exit.")
						actionLog = 'knownInfo'
	elif senType == 'open':
		if calc.__CALC__(sen,'firefox'):
			pl.printline(5)
			aiui.uiSpeak('Opening firefox... press Alt-F4 or use the exit button to close')
			os.system('firefox')
			actionLog = 'firefox'
		if calc.__CALC__(sen,'matrix'):
			print 'opening matrix'
			subprocess.Popen(['xterm','cmatrix','-T','PyAI \\\\ Press Control-C to exit.'])
			actionLog = 'matrix'
	elif senType == 'timer':
		aitimer.timer(sen)
		actionLog = 'timer'
	else:
		print 'No Command Recognized'
	aiutil.appendInputLog(actionLog)
	aiutil.updateFileNo()
	exit()

			
		
try:
	useSen = sys.argv[1]
except:
	print 'Loading Logic Module...'
	
if useSen == 'True':
	logic(sys.argv[2])
