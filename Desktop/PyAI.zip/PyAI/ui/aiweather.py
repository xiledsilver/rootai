'''
  Weather class for the AI. Dependent on Linux package 'weather-util', called via 'weather' in the term.
'''

import os
import time #Mainly for pause function... may have future functionality.
import printline as pl
import aiconfig   
import aiui
import aiwp


def getWeatherData(areaCode):
	print "Getting weather data... Please wait."
	os.system("weather -q -f " + areaCode + "> " + aiDirectory + "/weatherdata/messywdata.txt")
	os.system("weather -q -f " + areaCode +" > " + aiDirectory + "/weatherdata/wdata.txt") #Gets weaver via the 'weather' application. Does it twice to remove extra data.
	time.sleep(1)
	print "Weather data collected."
	weatherData = displayWeatherData()
	os.system('clear')
	pl.printline(3)
	return weatherData
	
	

def displayWeatherData():
	weatherData = open(aiDirectory + "/weatherdata/wdata.txt").read()
	cleanData = ""
	wdataLength = len(weatherData)
	for weatherPoint in range (wdataLength):
		if weatherData[weatherPoint] != '*':
			cleanData += (weatherData[weatherPoint])
		elif weatherData[weatherPoint] == '*':
			break
	return cleanData
	
	
def weatherMain(command):
	clen = len(command)
	command += '    '
	weatherLocation = ''
	for char in range(clen):
		if command[char] + command[char + 1] == 'in':
			for char2 in range(char + 3,clen):
				if command[char2] != '.' and command[char2] + command[char2 + 1] != '  ' and command[char2 - 1] + command[char2 - 2] != '  ' and command[char2] != '?' and command[char2] != '!':
					weatherLocation += command[char2]
	os.system('clear')
	aiui.uiSpeak("Is this the proper location? (Zip Code Only) \\\\  " + weatherLocation)	
	correctWLoc = raw_input("y/n \\\\  ")
	os.system('clear')
	pl.printline(5)
	if correctWLoc == 'y':
		print getWeatherData(weatherLocation)
		aiui.uiSpeak("Press return to exit.")
		exitOnReturn = raw_input("")
	else:
		aiui.uiSpeak("Enter requested Zip Code \\\\ ")
		zipCode = raw_input("")
		print getWeatherData(zipCode)
		pl.printline(4)
		aiui.uiSpeak("Press return to exit.")
		exitOnReturn = raw_input("")
aiDirectory = aiconfig.getDir()
