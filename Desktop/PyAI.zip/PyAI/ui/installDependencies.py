import os
import aiconfig

if aiconfig.getSecure() == False:
	password = aiconfig.getPassword()
	os.popen('echo '+password+' | sudo -S apt-get install firefox, cmatrix, python-pip, weather-util, galculator, nano, bc') 
	os.system('clear')
	os.system('pip install pyttsx')
	os.system('pip install wikipedia')
	os.system('pip install wolframalpha')
	os.system('clear')
	exit()
else:
	os.system('sudo apt-get install firefox, cmatrix, python-pip, weather-util, galculator, nano, bc')
	os.system('clear')
	os.system('pip install pyttsx')
	os.system('pip install wikipedia')
	os.system('pip install wolframalpha')
	os.system('clear')
	exit()


