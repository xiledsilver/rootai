'''
faceai
'''

import os, time


os.system('cd /home/rt/Desktop/PyAI/facial_recognition && python RUN.py')

