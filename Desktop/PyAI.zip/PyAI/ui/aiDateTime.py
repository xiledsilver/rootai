import time
import aiconfig
import printline as pl
import os

aiDir = aiconfig.getDir()


while True:
	os.system('date > ' + aiDir + '/miscdata/date.txt')
	time.sleep(0.9999)




