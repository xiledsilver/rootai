'''

	Neuron Module for PyAI

'''
import time 
import aiweather
import aisearch 
import aiwp 
import ailogic
import aitimer
import subprocess
import printline as pl
import aicalculate as calc
import aimemories
import aiui
import aiutil
import os
import aiconfig

global data
data = []

def num_patternRecog(data):
	print data
	datalen = len(data)-1
	for char in range(datalen):
		for char2 in range(datalen):
			for val in range(int(data[1] - data[0]+2)):
				val = long(val)
				if data[char]+val == data[char+1] and data[char2]+val == data[char2+1] and data[datalen]-val == data[datalen-1]:
					print ''
					return ['FUNCTION; ', 'f(x) = x + ' + float(val)]                                               # VAL NEEDS TO BE ABLE TO BE A FLOAT/SHORT, NOT INT!@!@!@!@!@!
			for val in range(int(data[1] + data[0]-2)):
				val = long(-val)
				if data[char]+val == data[char+1] and data[char2]+val == data[char2+1] and data[datalen]-val == data[datalen-1]:
					print ''
					return ['FUNCTION; ', 'f(x) = x - ' + float(-val)]
			for val in range(int(data[1]/data[0]+2)):
				val = long(val)
				if data[char]*val == data[char+1] and data[char2]*val == data[char2+1] and data[datalen]/val == data[datalen-1]:
					print ''
					return ['FUNCTION; ', 'f(x) = x * ' + float(val)]
			for val in range(1,int(data[1]*data[0]+2)):
				val = long(val)
				if data[char]/val == data[char+1] and data[char2]/val == data[char2+1] and data[datalen]*val == data[datalen-1]:
					print ''
					return ['FUNCTION; ', 'f(x) = x / ' + float(val)]
			if data[char]+1 == data[char+1] and data[char2]+1 == data[char2+1] and data[datalen]-1 == data[datalen-1]:
				if char2 == datalen-1:
					print ''
					return ['FUNCTION; ' , 'f(x) = x + 1']
			elif data[char]-1 == data[char+1] and data[char2]-1 == data[char2+1] and data[datalen]+1 == data[datalen-1]:
				if char2 == datalen-1:
					print ''
					return ['FUNCTION; ' , 'f(x) = x - 1']
			elif data[char]*2 == data[char+1] and data[char2]*2 == data[char2+1] and data[datalen-1] == data[datalen]/2:
				if char2 == datalen-1:
					print ''
					return ['FUNCTION; ' , 'f(x) = 2x']
			elif data[char]/2 == data[char+1] and data[char2]/2 == data[char2+1] and data[datalen-1] == data[datalen]*2:
				if char2 == datalen-1:
					print ''
					return ['FUNCTION; ' , 'f(x) = x/2']
			else:
				print ''
				return ['FUNCTION; ', 'f(x) = ?']
			
			


os.system('clear')
func = num_patternRecog([1.1,11])
print func[0] + func[1]
