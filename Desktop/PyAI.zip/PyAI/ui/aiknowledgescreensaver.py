import os
import aiconfig
import time
import aiutil
import random
import printline as pl
import subprocess


aiDir = aiconfig.getDir()
global knowledge
knowledge = []
printedAmnt = 0

while True:
	timeout = open(aiDir + "/miscdata/timeout.txt").read()
	memNo = aiutil.getMemAmnt()
	if timeout != '-0-':
		os.system('echo ' + str(int(timeout) + 1) + ' > ' + aiDir + '/miscdata/timeout.txt')
		if int(timeout) >= 10:
			for fileAmount in range(memNo):
				if fileAmount == 0:
					hasInfo = []
				knowledge.append(open(aiDir + '/miscdata/knowledge/mem' + str(fileAmount)).read().splitlines())
			number = random.randint(0,memNo-1)
			pl.printline(3)
			print knowledge[number][1]
			printedAmnt += 1
			if printedAmnt == 2:
				os.system('clear')
				printedAmnt = 0
				number = random.randint(0,memNo-1)
				pl.printline(3)
				print knowledge[number][1]
		
	time.sleep(1)

				
