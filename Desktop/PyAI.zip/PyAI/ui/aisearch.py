'''

	PyAI Search Module

	
'''

import googlemod
import wikipedia
import os
import printline as pl
import aiui
import aiutil

def searchOnline(commandO,returnSummary):
	wikipedia.set_lang('en')
	os.system('clear')
	command = ''
	pl.printline(5)
	for char in range(len(commandO)):
		if commandO[char] + commandO[char+1] + commandO[char+2] != '   ':
			command += commandO[char]
		else:
			break
	aiui.uiSpeak("Looking up information on \"" + command + "\".... Please wait.")
	wikipSummary = ""
	try:
		wikipSummary = wikipedia.summary(command, sentences = 3)
	except wikipedia.exceptions.PageError:
		os.system('clear')
		aiui.uiSpeak('No information on,\"' + command + '\", found.')
	except wikipedia.exceptions.DisambiguationError:
		os.system('clear')
		aiui.uiSpeak('Search phrase is too ambiguous... try to make it more precise.')
	except:
		os.system('clear')
		aiui.uiSpeak('Wikipedia error... please try again.')
	os.system('clear')
	pl.printline(2)
	aiui.uiSpeak('Information collected and stored.')
	print wikipSummary
	pl.printline(2)
	googlemod.google(command)
	pl.printline(3)
	if returnSummary:
		aiutil.storeMem(command,wikipSummary)
	print "Press return to exit."
	exitOnReturn = raw_input("")

