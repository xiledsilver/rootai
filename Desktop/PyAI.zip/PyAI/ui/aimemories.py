'''
	PyAI Memory Module
	------------------
	experimental.
	
'''

import time 
import aiweather
import os
import aiconfig
import aisearch 
import aiutil
import aiwp 
import ailogic
import aitimer
import subprocess
import printline as pl
import aicalculate as calc
import aiui

fileNo = aiutil.getFileNo()
global commands
global knowledge
global hasInfo
hasInfo = False
commands = []
knowledge = []
memNo = aiutil.getMemAmnt()
aiDirectory = aiconfig.getDir()

def loadMemories(message):
	memNo = aiutil.getMemAmnt()
	fileNo = aiutil.getFileNo()
	aiui.uiSpeak(message)
	for fileAmount in range(fileNo):
		if fileAmount == 0:
			commands = []
		print 'Loading log no. ' + str(fileAmount) + '...'
		commands.append(open(aiDirectory + '/miscdata/inputlogs/inputNo' + str(fileAmount)).read().splitlines())
	for fileAmount in range(memNo):
		if fileAmount == 0:
			hasInfo = []
		print 'Loading information database file no. ' + str(fileAmount) + '...'
		knowledge.append(open(aiDirectory + '/miscdata/knowledge/mem' + str(fileAmount)).read().splitlines())
	if message == 'Loading database information...':
		time.sleep(0.5)
	os.system('clear')

def checkMemories(sen):
	global hasInfo
	for fileNo in range(len(knowledge)):
		if calc.__CALC__(knowledge[fileNo][0],sen) and knowledge[fileNo][0] != ' ':
			hasInfo = True
			return knowledge[fileNo][1]
			break
		elif fileNo == len(knowledge)-1:
			hasInfo = False
			break

#loadMemories('Loading Memory Databases... Please wait.')
#print checkMemories('tyler')




