'''
	Secondary Prompt for PyAI

'''

import time 
import os
import aiconfig
import aisearch 
import aiutil
import ailogic
import printline as pl
import aimemories
import aiui

while True:
	aimemories.loadMemories('Updating database information...')
	os.system('clear')
	time.sleep(5)
	pl.printline(5)
	time.sleep(.1)
	aiutil.settimeout('0')
	aiui.uiSpeak('What are your commands?')
	ailogic.logic(raw_input("<>" + aiconfig.getName() + "@pyAI\\\\ ").lower())
	aiutil.updateFileNo()
	aiutil.settimeout('0')

