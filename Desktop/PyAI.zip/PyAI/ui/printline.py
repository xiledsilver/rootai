def printline(amount):
	for i in range(amount):
		print ""
