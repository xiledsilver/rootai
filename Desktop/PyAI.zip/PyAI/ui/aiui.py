import pygame
import time
import os
import aiutil
import aiconfig
from pygame.locals import *
aiDirectory = aiconfig.getDir()

bcolor = (250,250,250)
black = (0,0,0)             
red = (250,0,0)
screensize = (800,600)      # do not change this nor the font size in pyFont, as it will require messing around with numbers below.       
screenFactorx = screensize[0] / 25              # Do not put these numbers below 25, or above 50.
screenFactory = screensize[1] / 25
sidebarThickness = (screenFactorx * screenFactory) / 40    # Do not put this number below 25, or above 50.

leftStart = (screenFactorx,screenFactory)
leftEnd = (screenFactorx,screensize[1]-screenFactory)
rightStart =(screensize[0]-screenFactorx,screenFactory)
rightEnd = (screensize[0]-screenFactorx,screensize[1]-screenFactory)             # Sets the bounds for the side lines and triangle. Also gets the center of the screen.
screenCenter = (screensize[0]/2,screensize[1]/2)                                       
uiTriangle = ((screenCenter[0]-(screenFactorx / 3), screenCenter[1] + (screenFactory / 3)),(screenCenter[0]+(screenFactorx / 3),(screenCenter[1] + (screenFactory / 3))))

## init ui ##

pygame.init()
screen = pygame.display.set_mode(screensize)
screen.fill(bcolor)                     # Initializes the Pygame window with the screensize variable. Fills the background with the 'bcolor', default white.
pygame.display.flip()
pygame.display.set_caption("PyAI //// Terminal #" + str(aiutil.getInstancesAmnt()))
pyFont = pygame.font.SysFont("monospace", 19)   # do not change font size.
message = "<>"     # Sets the message to avoid any errors with uiSpeak being called with a blank arg. 

##         ##

def setup_ui(launch,message):
	screen.fill(bcolor)                 
	for sbl in range(sidebarThickness):
		leftStartm = (leftStart[0] + sbl, leftStart[1] + sbl)
		leftEndm = (leftEnd[0] + sbl, leftEnd[1] - sbl)
		rightStartm = (rightStart[0] - sbl, rightStart[1] + sbl)     # Draws the side lines, with a slight decrease in the y-length.
		rightEndm = (rightEnd[0] - sbl, rightEnd[1] - sbl)
		pygame.draw.line(screen, black, leftStartm, leftEndm)
		pygame.draw.line(screen, black, rightStartm, rightEndm)
		if launch:
			pygame.display.flip()
			time.sleep(0.05)
	pygame.display.flip()
	if launch:
		time.sleep(0.5)
	pygame.draw.polygon(screen,red,(screenCenter,uiTriangle[0],uiTriangle[1]))    # Draws a red triangle in the middle.
	if not launch:
		pygame.draw.line(screen,black,(screenCenter[0] - (5.5 * len(message) ), screenCenter[1]),(screenCenter[0] + (5.5 * len(message) ),screenCenter[1]))
		pygame.draw.line(screen,black,(screenCenter[0] - (5.5 * len(message) ), screenCenter[1]-1),(screenCenter[0] + (5.5 * len(message) ),screenCenter[1]-1)) # Draws lines above triangle in length similar to length of message.
		pygame.draw.line(screen,black,(screenCenter[0] - (5.5 * len(message) ), screenCenter[1]-2),(screenCenter[0] + (5.5 * len(message) ),screenCenter[1]-2))
		pygame.display.flip()
	
def uiSpeak(message):
	setup_ui(False,message)
	uiTextbox = pyFont.render(message,1,black)
	screen.blit(uiTextbox, (screenCenter[0] - (sidebarThickness/3.5) * len(message),screenCenter[1] - (sidebarThickness/0.9)))       # Redraws the ui, then blits the text to the screen.
	pygame.display.flip()
	

#setup_ui(True,'Hello,      ') # Sets up the initial UI with a drawing animaton (pause for 0.01 seconds after each frame update.)
#while True:
	#if not pygame.constants.keyboard (RETURN):
		#print 'quitting'
		#pygame.quit()
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

