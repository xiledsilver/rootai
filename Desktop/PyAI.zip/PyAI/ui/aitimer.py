import time as pyTime
import aiui
import aiutil
import aiwp
import os
import printline as pl

timeCount = 0
timeRemaining = 0




def timer(command):
	timeCount = 0
	deciCount = 0
	timeRemaining = 0
	comWords = aiutil.listify(command)
	comWords.reverse()
	timerAmount = 0
	minuteAmount = 0
	minuteToSecond = 0
	timerDone = False
	timerStr = '0'
	for wordLen in range(len(comWords)):
		if comWords[wordLen] == 'minutes' or comWords[wordLen] == 'minute':
			minuteAmount = float(comWords[wordLen + 1])
			comWords[wordLen + 1] = '--'
		elif aiwp.wp(comWords[wordLen]) == 'num':
			timerStr += comWords[wordLen]
			comWords[wordLen] = '--'
		elif comWords[wordLen] == "." and aiwp.wp(comWords[wordLen-1]) == 'num' and aiwp.wp(comWords[wordLen+1]) == 'num':
			timerStr += "."
		elif comWords[wordLen] == 'for':
			break
	minuteToSecond = minuteAmount * 60
	timerAmount += int(round(float(timerStr)))
	timerAmount += minuteToSecond
	os.system('clear')
	aiui.uiSpeak("Timer set for " + str(timerAmount) + " seconds.")
	pyTime.sleep(1)
	if timerAmount == 0:
		pyTime.sleep(1)
	while True:
		pyTime.sleep(1)
		timeCount += 1
		if (timerAmount - timeCount) >= 60:
			aiui.uiSpeak("Time Remaining: " + str(int(((timerAmount - timeCount) / 60))) + 'm ' + str((timerAmount - timeCount) % 60)+ ' s')
		else:
			aiui.uiSpeak("Time Remaining: " + str(timerAmount - timeCount) + 's')
		if timeCount == timerAmount:
			os.system('clear')
			aiui.uiSpeak("Timer for " + str(timerAmount) + " seconds complete! Press return to exit.")
			pl.printline(2)
			exitOnReturn = raw_input('')
			break
	

